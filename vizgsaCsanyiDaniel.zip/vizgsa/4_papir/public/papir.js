function getCalc() {
    let szelesseg = document.getElementById('szelesseg').value;
    let magassag = document.getElementById('magassag').value;
    let terulet = Math.round((szelesseg * magassag) / 10000);
    let papirtipus = document.getElementById('papirtipus').value
    let koltseg = terulet * papirtipus
     
     if(magassag < 50 || szelesseg < 50) {
        alert('Ellenőrizze az adatokat!');
    }

    document.getElementById('terulet').style.backgroundColor="white";
    document.getElementById('terulet').style.color="green";
    document.getElementById('terulet').style.fontWeight="bold";
    document.getElementById('koltseg').style.backgroundColor="white";
    document.getElementById('koltseg').style.color="green";
    document.getElementById('koltseg').style.fontWeight="bold";

   
    
    document.getElementById('terulet').innerText = terulet;
    document.getElementById('koltseg').innerText = koltseg;

    if( koltseg > 500){
        document.getElementById('koltseg').style.color="red";
    }

}