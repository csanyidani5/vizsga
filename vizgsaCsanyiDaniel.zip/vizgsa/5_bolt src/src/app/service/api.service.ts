import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  myUrl= "https://jsonplaceholder.typicode.com/photos"
  constructor(private myHttp: HttpClient) { }

  getData(){
    return this.myHttp.get(this.myUrl);
  }
}
