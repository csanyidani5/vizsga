import { Component } from '@angular/core';
import { ApiService } from '../service/api.service';


@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent {
  data: any;
  constructor(private myApi:ApiService){
    this.myApi.getData().subscribe(res => {
      this.data= res;
    })
   }
}
