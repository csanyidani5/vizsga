import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent {
  myForm: any;
  constructor(private fb: FormBuilder ){}

  ngOnInit(){
    this.myForm = this.fb.group ({
      name:["", Validators.required],
      email: ["", [Validators.required, Validators.email]],
      gdpr: ["", Validators.required]
    })
    }
    get name(){
      return this.myForm.get('name')
    }
    get email(){
      return this.myForm.get('email')
    }
    get gdpr(){
      return this.myForm.get('gdpr')
    }
    
  }


